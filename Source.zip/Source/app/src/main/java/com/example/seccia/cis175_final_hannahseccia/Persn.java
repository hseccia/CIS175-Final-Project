package com.example.seccia.cis175_final_hannahseccia;

import android.os.Parcel;
import android.os.Parcelable;

public class Persn implements Parcelable{                       //parcelable implemented so that arraylist can be intent-friendly and passed inbetween them

    private String fName;
    private String lName;
    private String username;
    private String password;
    private String email;
    private int age;
    private int wins;
    private int losses;


    public Persn ()                                             //empty constructor so that new instances may be created
    {

    }

    protected Persn(Parcel in) {
        fName = in.readString();
        lName = in.readString();
        username = in.readString();
        password = in.readString();
        email = in.readString();
        age = in.readInt();
    }

    public static final Creator<Persn> CREATOR = new Creator<Persn>() {
        @Override
        public Persn createFromParcel(Parcel in) {
            return new Persn(in);
        }

        @Override
        public Persn[] newArray(int size) {
            return new Persn[size];
        }
    };

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public int getLosses() {
        return losses;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fName);
        dest.writeString(lName);
        dest.writeString(username);
        dest.writeString(password);
        dest.writeString(email);
        dest.writeInt(age);
    }
}
