package com.example.seccia.cis175_final_hannahseccia;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

//Author: Hannah Seccia
//Date: November 19, 2018
//Description: Full Create-Read-Update-Delete Database Application (Connect Four Game)


public class MainActivity extends AppCompatActivity {

    TextView j_login_title;
    TextView j_login_enterUserText;
    TextView j_login_enterPasswordText;
    TextView j_login_registerText;

    EditText j_login_enterUsername;
    EditText j_login_enterPassword;

    Button j_login_registerBtn;
    Button j_login_loginBtn;

    Intent j_add_Screen;
    Intent j_menu_Screen;

    ArrayList<Persn> j_main_myPpl;
    DatabaseHelper dbHelper;
    static boolean startUp = true;

    String tempLoginName;
    String tempLoginPass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        j_login_title = (TextView)findViewById(R.id.v_login_title);
        j_login_enterUserText = (TextView)findViewById(R.id.v_login_enterUserText);
        j_login_enterPasswordText = (TextView)findViewById(R.id.v_login_enterPasswordText);
        j_login_registerText = (TextView)findViewById(R.id.v_login_registerText);

        j_login_enterUsername = (EditText)findViewById(R.id.v_login_enterUsername);
        j_login_enterPassword = (EditText)findViewById(R.id.v_login_enterPassword);

        j_login_registerBtn = (Button)findViewById(R.id.v_login_registerBtn);
        j_login_loginBtn = (Button)findViewById(R.id.v_login_loginBtn);

        j_main_myPpl = new ArrayList<Persn>();

        dbHelper = new DatabaseHelper(this);



    }

    @Override
        protected void onResume()
        {
           super.onResume();
            if(startUp)
            {
                dbHelper.db_initDatabase();                                                         //db only initiated once on program startup
                j_main_myPpl = dbHelper.getAllRows();


                checkLoginClick();
                checkRegisterClick();
                startUp = false;

            }
            else if(!startUp)
            {
                Intent previousIntent = getIntent();                                                //the array is passed
                j_main_myPpl = previousIntent.getParcelableArrayListExtra("Persons");         //back everytime

                j_main_myPpl = dbHelper.getAllRows();

                tempLoginName = "";                                                                 //making sure there's not a double login/data leakage
                tempLoginPass = "";


                checkLoginClick();
                checkRegisterClick();

            }


        }



    void checkLoginClick()
    {
        j_login_loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                checkLoginValid();

            }
        });



    }

    void checkRegisterClick()
    {
        j_login_registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                goToAddScreen();

            }
        });
    }

    void checkLoginValid()
    {
        tempLoginName = j_login_enterUsername.getText().toString();
        tempLoginPass = j_login_enterPassword.getText().toString();

        if (tempLoginName.equals("") && tempLoginPass.equals(""))                                   //https://bytes.com/topic/java/answers/827820-testing-if-string-not-equal
        {                                                                                           //if both text fields are empty
            Toast.makeText(this, "Please insert a username and password.", Toast.LENGTH_SHORT).show();
        }
        else if (tempLoginName.equals("")|| tempLoginPass.equals(""))                               //if one of the text fields are empty
        {
            Toast.makeText(this, "Please enter both a username and password.", Toast.LENGTH_SHORT).show();
        }
        else if (!tempLoginName.equals("") && !tempLoginPass.equals(""))                            //if both fields are filled
        {
            int tableRowSize = dbHelper.db_numOfRows();

            for (int i = 0; i < tableRowSize; i++)
            {

                if (!tempLoginName.equals(j_main_myPpl.get(i).getUsername()) || !tempLoginPass.equals(j_main_myPpl.get(i).getPassword()))
                {
                    Toast.makeText(this, "Incorrect username or password.", Toast.LENGTH_SHORT).show();
                }
                else if(tempLoginName.equals(j_main_myPpl.get(i).getUsername()) && tempLoginPass.equals(j_main_myPpl.get(i).getPassword()))
                {
                    goToMenu(i);
                    break;                                                                          //attempt to fix toast error upon correct login
                }

            }
        }
    }

    void goToMenu(int position)
    {
        j_menu_Screen = new Intent(MainActivity.this, UserMenuScreen.class);
        j_menu_Screen.putParcelableArrayListExtra("Persons", j_main_myPpl);
        j_menu_Screen.putExtra("Position",position);
        startActivity(j_menu_Screen);
    }

    void goToAddScreen()
    {
        j_add_Screen = new Intent(MainActivity.this, AddUser.class);
        j_add_Screen.putParcelableArrayListExtra("Persons", j_main_myPpl);
        startActivity(j_add_Screen);

    }

                                                                                         //https://stackoverflow.com/questions/8452526/android-can-i-use-putextra-to-pass-multiple-values

}

