package com.example.seccia.cis175_final_hannahseccia;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper
{
    public static final String USER_DATABASE = "user.db";
    public static final String USER_MAIN_TABLE = "userMainTable";

    public DatabaseHelper(Context context)
    {
        super(context, USER_DATABASE, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE userMainTable (firstname TEXT, lastname TEXT, username TEXT PRIMARY KEY NOT NULL, password TEXT, email TEXT, age INT, wins INT, losses INT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + USER_MAIN_TABLE);
        onCreate(db);

    }

    public boolean db_initDatabase()
    {
        if (db_numOfRows() == 0)
        {
            SQLiteDatabase db = this.getWritableDatabase();

            db.execSQL("INSERT INTO " + USER_MAIN_TABLE + " VALUES('Hannah', 'Seccia', 'hseccia', 'pass','hseccia00@gmail.org', '18', '30', '0');");

            db.close();

            return true;
        }
        else
        {
            return false;
        }
    }

    public int db_numOfRows()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        int numOfRows = (int) DatabaseUtils.queryNumEntries(db, USER_MAIN_TABLE);
        db.close();
        return numOfRows;
    }

    public ArrayList<Persn> getAllRows()
    {
        ArrayList<Persn> userList = new ArrayList<Persn>();
        String selectQuery = "SELECT * FROM " + USER_MAIN_TABLE + ";";
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst())                                                                   //if table isnt empty, also moves cursor to first
        {

            do {

                Persn persn = new Persn();
                persn.setfName(cursor.getString(cursor.getColumnIndex("firstname")));
                persn.setlName(cursor.getString(cursor.getColumnIndex("lastname")));
                persn.setUsername(cursor.getString(cursor.getColumnIndex("username")));
                persn.setPassword(cursor.getString(cursor.getColumnIndex("password")));
                persn.setEmail(cursor.getString(cursor.getColumnIndex("email")));
                persn.setAge(cursor.getInt(cursor.getColumnIndex("age")));
                persn.setWins(cursor.getInt(cursor.getColumnIndex("wins")));
                persn.setLosses(cursor.getInt(cursor.getColumnIndex("losses")));
                userList.add(persn);

            }
            while (cursor.moveToNext());                                                            //while cursor doesn't reach the end
        }

        db.close();

        return userList;
    }

    public void addNewUser(String firstnameParse, String lastnameParse, String usernameParse, String passwordParse,
                           String emailParse, int ageParse)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO " + USER_MAIN_TABLE + " VALUES('" + firstnameParse + "', '" + lastnameParse + "', '" + usernameParse + "', '" + passwordParse +"', '" + emailParse + "',  '" + ageParse + "', '"+ 0 + "', '"+ 0 +"');");

        db.close();
    }

    public void deleteUser(String usernameParse)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + USER_MAIN_TABLE + " WHERE username = '" + usernameParse + "'");
        db.close();
    }

    public void updateUser(String fNameParse, String lNameParse, String passwordParse, String emailParse, String usernameParse)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("UPDATE " + USER_MAIN_TABLE + " SET firstname = '" + fNameParse + "' WHERE username = '"+ usernameParse + "'");
        db.execSQL("UPDATE " + USER_MAIN_TABLE + " SET lastname = '" + lNameParse + "' WHERE username = '"+ usernameParse + "'");
        db.execSQL("UPDATE " + USER_MAIN_TABLE + " SET password = '" + passwordParse + "' WHERE username = '"+ usernameParse + "'");
        db.execSQL("UPDATE " + USER_MAIN_TABLE + " SET email = '" + emailParse + "' WHERE username = '"+ usernameParse + "'");

        db.close();
    }

    public void updateUserWins(int winsParse, int lossesParse, String usernameParse)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("UPDATE " + USER_MAIN_TABLE + " SET wins = '" + winsParse +"' WHERE username = '" + usernameParse +"'");
        db.execSQL("UPDATE " + USER_MAIN_TABLE + " SET losses = '" + lossesParse +"' WHERE username = '" + usernameParse +"'");

        db.close();
    }

}
