package com.example.seccia.cis175_final_hannahseccia;

import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class GameActivity extends AppCompatActivity {


    ImageView[][] j_cellsView;
    Connect4Cell[][] j_cells;
    Button[] j_dropButtons;

    Boolean isPlayerTurn = true;
    Boolean compCellFound = false;
    Boolean strategyBlockJustAttempted = false;
    Boolean chipOnSameLayer = true;
    Boolean gameWin = false;
    String blockTypeBeingProcessed;
    Intent j_userMenuScreen;
    ArrayList<Persn> j_game_myPpl;
    DatabaseHelper dbHelper;
    MediaPlayer chipSlip;

    int tempRowParseCount;
    int tempColumnParseCount;

    int tempRowPlayerChip;
    int tempColumnPlayerChip;

    int position;

    Button j_gameBackToMenuBtn;
    TextView j_gameTurnText;
    TextView j_gameWinMessageText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        Intent previousIntent = getIntent();
        j_game_myPpl = previousIntent.getParcelableArrayListExtra("Persons");
        position = previousIntent.getIntExtra("Position", 0);

        j_userMenuScreen = new Intent(GameActivity.this, UserMenuScreen.class);


        dbHelper = new DatabaseHelper(this);

        chipSlip = MediaPlayer.create(this, R.raw.slip);

        initGameBoard();


        checkBoardClick();
        boardClickProcessing();

        checkBackButtonClick();

    }

    void initGameBoard() {

        j_cellsView = new ImageView[6][7];
        j_cells = new Connect4Cell[6][7];


        int getID;                                                          //i was curious to find a way to find a way to initialize
        for (int i = 0; i < 6; i++)                                         //all the game pieces without manually typing them out.
        {                                                                   //when studying the findviewbyID, i made the cell names "dyanmic"
            for (int j = 0; j < 7; j++)                                     //so they could be string-concatenated and still found by their id
                                                                            // (tempvariables to prevent 0 use in string-concatenation)
            {                                                               //https://stackoverflow.com/questions/29522610/is-possible-to-do-findviewbyid-with-i-variable
                tempRowParseCount = i + 1;
                tempColumnParseCount = j + 1;

                getID = getResources().getIdentifier(("v_gameCell_" + tempRowParseCount + "x" + tempColumnParseCount), "id", getPackageName());
                j_cellsView[i][j] = (ImageView) findViewById(getID);
            }
        }

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                j_cells[i][j] = new Connect4Cell();
                j_cells[i][j].setCellFull(false);
                j_cells[i][j].setCellTakenByPlayer(false);
            }
        }

        j_dropButtons = new Button[7];

        j_dropButtons[0] = (Button)findViewById(R.id.v_gameDropBtn_col1);
        j_dropButtons[1] = (Button)findViewById(R.id.v_gameDropBtn_col2);
        j_dropButtons[2] = (Button)findViewById(R.id.v_gameDropBtn_col3);
        j_dropButtons[3] = (Button)findViewById(R.id.v_gameDropBtn_col4);
        j_dropButtons[4] = (Button)findViewById(R.id.v_gameDropBtn_col5);
        j_dropButtons[5] = (Button)findViewById(R.id.v_gameDropBtn_col6);
        j_dropButtons[6] = (Button)findViewById(R.id.v_gameDropBtn_col7);


        j_dropButtons[0].setEnabled(true);
        j_dropButtons[1].setEnabled(true);
        j_dropButtons[2].setEnabled(true);
        j_dropButtons[3].setEnabled(true);
        j_dropButtons[4].setEnabled(true);
        j_dropButtons[5].setEnabled(true);
        j_dropButtons[6].setEnabled(true);


        j_gameBackToMenuBtn = (Button) findViewById(R.id.v_gameBackToMenuBtn);
        j_gameTurnText = (TextView) findViewById(R.id.v_gameTurnText);
        j_gameWinMessageText = (TextView)findViewById(R.id.v_gameWinMessageTxt);
    }

    void checkBackButtonClick() {
        j_gameBackToMenuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                j_userMenuScreen.putParcelableArrayListExtra("Persons", j_game_myPpl);
                j_userMenuScreen.putExtra("Position",position);
                startActivity(j_userMenuScreen);

            }
        });
    }


    void setPlayerChipOnCell(int row, int column) {

        if (!j_cells[row][column].isCellFull() && isPlayerTurn) 
        {

            j_cells[row][column].setCellFull(true);
            j_cells[row][column].setCellTakenByPlayer(true);
            j_cellsView[row][column].setImageResource(R.drawable.playerboardcell);
            isPlayerTurn = false;                                                       //switch control to CPU
            compCellFound = false;
            changeTurnText();
            strategyBlockJustAttempted = false;

            tempRowPlayerChip = row;
            tempColumnPlayerChip = column;

            chipSlip.start();

            checkForWin();

            new CountDownTimer(3000, 1000) {                                                  //https://stackoverflow.com/questions/10032003/how-to-make-a-countdown-timer-in-android

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {
                boardClickProcessing();
            }
        }.start();




        } 
        
    }

    void changeTurnText()
    {
        if (isPlayerTurn)
        {
            j_gameTurnText.setText("Player's turn");
            j_gameTurnText.setTextColor(Color.RED);
        }
        if (!isPlayerTurn)
        {
            j_gameTurnText.setText("Computer's turn");
            j_gameTurnText.setTextColor(Color.parseColor("#f0e130"));           //slightly darker yellow used for readability
        }
    }


    void boardClickProcessing()
    {
        if (!isPlayerTurn)
        {


            if (!strategyBlockJustAttempted && !compCellFound) {


                determineHorizontalBlock();
                determineVerticalBlock();
                determineDiagonalBlock();

            }

            if (strategyBlockJustAttempted && !compCellFound)
            {

                setComputerChipOnCell();
            }
        }
    }


    void determineHorizontalBlock()
    {

        blockTypeBeingProcessed = "horizontal";



        if (tempColumnPlayerChip == 0)
        {
            horizontalBlockLeftMostColumn();
        }
        else if (tempColumnPlayerChip == 1)
        {
            horizontalBlock2ndColumn();
        }
        else if (tempColumnPlayerChip == 2)
        {
            horizontalBlock3rdColumn();
        }
        else if (tempColumnPlayerChip == 3)
        {
            horizontalBlock4thColumn();
        }
        else if (tempColumnPlayerChip == 4)
        {
            horizontalBlock5thColumn();
        }
        else if (tempColumnPlayerChip == 5)
        {
            horizontalBlock6thColumn();
        }
        else if (tempColumnPlayerChip == 6)
        {
            horizontalBlockRightMostColumn();
        }

            strategyBlockJustAttempted = true;

    }

    void blockConfirm()
    {
        isPlayerTurn = true;
        changeTurnText();
        compCellFound = true;
        checkForWin();

    }


    void checkIfChipPossibleLayer()                                                          //to check if chip can be placed on same layer
    {


        if (tempRowPlayerChip == 5)
        {
            chipOnSameLayer = true;
        }

        if (tempRowPlayerChip < 5)                                                             //don't run if it's the bottom-most row or if its the right most column
        {

            if (tempColumnPlayerChip != 0)
            {

                if (j_cells[tempRowPlayerChip + 1][tempColumnPlayerChip + 1].isCellFull() && j_cells[tempRowPlayerChip + 1][tempColumnPlayerChip - 1].isCellFull())          //check the row right below it of the column next to it
                {
                    chipOnSameLayer = true;
                } else {
                    chipOnSameLayer = false;
                }
            }
        }

        }


    void horizontalBlockLeftMostColumn()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //scan check for placing 3 chips in the "right" direction
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip + 3].isCellFull())
        {
            checkIfChipPossibleLayer();

            if(chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 3].setCellFull(true);             // places it to the right of clicked chip
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip + 3].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }
        }

    }

    void horizontalBlock2ndColumn()
    {

        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           // scan check for placing matching chip in between two matching ones
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&   // (if left most chip is already full)
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip + 2].isCellFull())
        {

            checkIfChipPossibleLayer();
            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 2].setCellFull(true);             // places it to the right of the chip string
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip + 2].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }

        }

        horizontalBlockRightScan();


    }


    void horizontalBlock3rdColumn()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //check to perform if "left directon" move near the end of the board
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellFull())
        {

            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].setCellFull(true);             // places it to the left of clicked chip
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip + 1].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }

        }

            horizontalBlockRightScan();
            horizontalBlockInbetweenScan();

    }

    void horizontalBlock4thColumn()
    {
        horizontalBlockLeftScan();
        horizontalBlockRightScan();
        horizontalBlockInbetweenScan();
    }

    void horizontalBlock5thColumn()
    {

        horizontalBlockLeftScan();

        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //check to perform scanning to the "right" of the current chip click
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellFull())
        {

            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].setCellFull(true);             // places it to the left of clicked chip
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip - 1].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }

        }

        horizontalBlockInbetweenScan();

    }

    void horizontalBlock6thColumn()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           // scan check for placing matching chip in between two matching ones
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].isCellFull())
        {
            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].setCellFull(true);             // places it to the left of the chip string
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip - 2].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }
        }

        horizontalBlockLeftScan();
    }

    void horizontalBlockRightMostColumn()
    {

        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //scan check for placing 3 chips in the "right" direction
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip - 3].isCellFull())
        {
            checkIfChipPossibleLayer();

            if(chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 3].setCellFull(true);             // places it to the right of clicked chip
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip - 3].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }

        }
    }

    void horizontalBlockLeftScan()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //check to perform scanning to the "left" of the current chip click
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellFull())
        {


            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].setCellFull(true);             // places it to the right of clicked chip
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip + 1].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }
        }

       else if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //check to perform scanning to the "left" of the current chip click
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellFull() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip - 3].isCellFull())
        {

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 3].setCellFull(true);
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip - 3].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }

        }

    }

    void horizontalBlockRightScan()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //check to perform scanning to the "right" of the current chip click
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellFull())
        {

            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].setCellFull(true);             // places it to the left of clicked chip
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip - 1].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }

        }

        else if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           // if left of the clicked chip is already full
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 2].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellFull() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip + 3].isCellFull())
        {

            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 3].setCellFull(true);             // places it to the right of clicked chip
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip + 3].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }

        }

    }

    void horizontalBlockInbetweenScan()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           // scan check for placing matching chip in between two matching ones
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].isCellFull())
        {
            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].setCellFull(true);             // places it to the left of the chip string
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip - 2].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }
        }

       else if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           // scan check for placing matching chip in between two matching ones
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&   // (if left most chip is already full)
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip][tempColumnPlayerChip - 2].isCellFull() &&
                !j_cells[tempRowPlayerChip][tempColumnPlayerChip + 2].isCellFull())
        {

            checkIfChipPossibleLayer();
            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip][tempColumnPlayerChip + 2].setCellFull(true);             // places it to the right of the chip string
                j_cellsView[tempRowPlayerChip][tempColumnPlayerChip + 2].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }

        }
    }

    void determineVerticalBlock()
    {

        blockTypeBeingProcessed = "vertical";

        if (tempRowPlayerChip < 4 && tempRowPlayerChip != 0)
        {                                                                                           //any row below the 2rd one cannot match 4 vertically when counting downward
                                                                                                    //, and the top most row cannot be blocked vertically
            if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //scan check for placing 3 chips in the "right" direction
                    j_cells[tempRowPlayerChip + 1][tempColumnPlayerChip].isCellTakenByPlayer() &&
                    j_cells[tempRowPlayerChip + 2][tempColumnPlayerChip].isCellTakenByPlayer())
            {
                j_cells[tempRowPlayerChip - 1][tempColumnPlayerChip].setCellFull(true);
                j_cellsView[tempRowPlayerChip - 1][tempColumnPlayerChip].setImageResource(R.drawable.compboardcell);
                blockConfirm();

            }
        }

    }

    void determineDiagonalBlock()
    {

        blockTypeBeingProcessed = "diagonal";

        if (tempRowPlayerChip == 0 || tempRowPlayerChip == 1)
        {
            if (tempColumnPlayerChip == 0 || tempColumnPlayerChip == 1 || tempColumnPlayerChip == 2)
            {
                diagonalRightLowerBlock();
            }

            else if (tempColumnPlayerChip == 3)
            {
                diagonalLeftLowerBlock();
                if (!compCellFound)
                {
                    diagonalRightLowerBlock();
                }
            }

            else if (tempColumnPlayerChip == 4 || tempColumnPlayerChip == 5 || tempColumnPlayerChip == 6)
            {
                diagonalLeftLowerBlock();
            }
        }

        else if (tempRowPlayerChip == 2)
        {
            if (tempColumnPlayerChip == 0)
            {
                diagonalRightLowerBlock();
            }

            else if (tempColumnPlayerChip == 1)
            {
                diagonalRightUpperBlock();                                                          //CHANGE TO PLACE LEFT
                if (!compCellFound)
                {
                    diagonalRightLowerBlock();
                }

            }
            else if (tempColumnPlayerChip == 2)
            {

                diagonalLeftUpperBlock();
                if (!compCellFound)
                {
                    diagonalRightUpperBlock();
                }
                if (!compCellFound)
                {
                    diagonalRightLowerBlock();
                }

            }
            else if (tempColumnPlayerChip == 3)
            {
                diagonalRightLowerBlock();

                if (!compCellFound)
                {
                    diagonalLeftLowerBlock();
                }
                if (!compCellFound)
                {
                    diagonalRightUpperBlock();
                }
                if (!compCellFound)
                {
                    diagonalLeftUpperBlock();
                }
            }
            else if (tempColumnPlayerChip == 4)
            {

                diagonalRightUpperBlock();

                if (!compCellFound)
                {
                    diagonalLeftUpperBlock();
                }
                if (!compCellFound)
                {
                    diagonalLeftLowerBlock();
                }

            }
            else if (tempColumnPlayerChip == 5)
            {
                diagonalLeftLowerBlock();

                if (!compCellFound)
                {
                    diagonalLeftUpperBlock();
                }
            }
            else if (tempColumnPlayerChip == 6)
            {

                diagonalLeftLowerBlock();

            }
        }
        else if (tempRowPlayerChip == 3 || tempRowPlayerChip == 4)
        {
            if (tempColumnPlayerChip == 1)
            {
                diagonalRightUpperBlock();
            }
            else if (tempColumnPlayerChip == 2 || tempColumnPlayerChip == 3 || tempColumnPlayerChip == 4)
            {
                diagonalRightUpperBlock();

                if (!compCellFound)
                {
                    diagonalLeftUpperBlock();
                }
            }
            else if (tempColumnPlayerChip == 5)
            {
                diagonalLeftUpperBlock();
            }

        }

    }

    void diagonalRightLowerBlock()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //scan check for placing 3 chips in the "right" direction downwards
                j_cells[tempRowPlayerChip + 1][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip + 2][tempColumnPlayerChip + 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip + 3][tempColumnPlayerChip + 3].isCellTakenByPlayer())
        {
            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip + 3][tempColumnPlayerChip + 3].setCellFull(true);
                j_cellsView[tempRowPlayerChip + 3][tempColumnPlayerChip + 3].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }
        }
    }

    void diagonalLeftLowerBlock()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //scan check for placing 3 chips in the "right" direction downwards
                j_cells[tempRowPlayerChip + 1][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip + 2][tempColumnPlayerChip - 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip + 3][tempColumnPlayerChip - 3].isCellTakenByPlayer())
        {
            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip + 3][tempColumnPlayerChip - 3].setCellFull(true);
                j_cellsView[tempRowPlayerChip + 3][tempColumnPlayerChip - 3].setImageResource(R.drawable.compboardcell);
                blockConfirm();
            }
        }
    }


    void diagonalRightUpperBlock()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //scan check for placing 3 chips in the "right" direction downwards
                j_cells[tempRowPlayerChip - 1][tempColumnPlayerChip + 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip - 2][tempColumnPlayerChip + 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip - 3][tempColumnPlayerChip + 3].isCellTakenByPlayer()) {
            checkIfChipPossibleLayer();

            if (chipOnSameLayer) {

                j_cells[tempRowPlayerChip - 3][tempColumnPlayerChip + 3].setCellFull(true);
                j_cellsView[tempRowPlayerChip - 3][tempColumnPlayerChip + 3].setImageResource(R.drawable.compboardcell);
                blockConfirm();

            }
        }
    }

    void diagonalLeftUpperBlock()
    {
        if (j_cells[tempRowPlayerChip][tempColumnPlayerChip].isCellTakenByPlayer() &&           //scan check for placing 3 chips in the "right" direction downwards
                j_cells[tempRowPlayerChip - 1][tempColumnPlayerChip - 1].isCellTakenByPlayer() &&
                j_cells[tempRowPlayerChip - 2][tempColumnPlayerChip - 2].isCellTakenByPlayer() &&
                !j_cells[tempRowPlayerChip + 1][tempColumnPlayerChip + 1].isCellTakenByPlayer())
        {
            checkIfChipPossibleLayer();

            if (chipOnSameLayer)
            {
                j_cells[tempRowPlayerChip + 1][tempColumnPlayerChip + 1].setCellFull(true);
                j_cellsView[tempRowPlayerChip + 1][tempColumnPlayerChip + 1].setImageResource(R.drawable.compboardcell);
                blockConfirm();

            }
        }
     }



    void setComputerChipOnCell() {


        if (!isPlayerTurn)
        {

            while (!compCellFound)
            {
                Random random = new Random();
                int tempRandomColumn = random.nextInt(7);                                   // //https://stackoverflow.com/questions/21049747/how-can-i-generate-a-random-number-in-a-certain-range/21049922


                for (int i = 5; i > -1; i--)
                {

                    if (!j_cells[i][tempRandomColumn].isCellFull())
                    {
                        j_cells[i][tempRandomColumn].setCellFull(true);
                        j_cellsView[i][tempRandomColumn].setImageResource(R.drawable.compboardcell);
                        isPlayerTurn = true;
                        changeTurnText();
                        compCellFound = true;
                        chipSlip.start();
                        checkForWin();
                        break;

                    }
                }


            }

        }


    }

    void checkForWin()
    {




        for (int i = 0; i < 6; i++)
            {

                for (int j = 0; j < 4; j++) {


                    if (j_cells[i][j].isCellTakenByPlayer() && j_cells[i][j+1].isCellTakenByPlayer() && j_cells[i][j+2].isCellTakenByPlayer() && j_cells[i][j+3].isCellTakenByPlayer()) {

                        gameWin = true;
                        gameWinActivate();
                    }


                    if (gameWin) {

                        break;


                    }

                }

                if (gameWin)
                {
                    break;
                }
            }

        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 3; j++)
            {


                if(j_cells[j][i].isCellTakenByPlayer() && j_cells[j+1][i].isCellTakenByPlayer() && j_cells[j+2][i].isCellTakenByPlayer() && j_cells[j+3][i].isCellTakenByPlayer())
                {

                    gameWin = true;
                    gameWinActivate();

                    if (gameWin) {
                        break;
                    }
                }

            }

            if (gameWin)
            {
                break;
            }

        }


        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 4; j++) {

                if (j_cells[i][j].isCellFull() && !j_cells[i][j].isCellTakenByPlayer())
                {
                    if (j_cells[i][j+1].isCellFull() && !j_cells[i][j+1].isCellTakenByPlayer())
                    {
                        if (j_cells[i][j+2].isCellFull() && !j_cells[i][j+2].isCellTakenByPlayer())
                        {
                            if (j_cells[i][j+3].isCellFull() && !j_cells[i][j+3].isCellTakenByPlayer())
                            {
                                gameWinActivateComp();
                                gameWin = true;
                            }
                        }
                    }

                }

                if (gameWin) {

                    break;
                }

            }

            if (gameWin)
            {
                break;
            }
        }

        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 3; j++)
            {

                if (j_cells[j][i].isCellFull() && !j_cells[j][i].isCellTakenByPlayer())
                {
                    if (j_cells[j+1][i].isCellFull() && !j_cells[j+1][i].isCellTakenByPlayer())
                    {
                        if (j_cells[j+2][i].isCellFull() && !j_cells[j+2][i].isCellTakenByPlayer())
                        {
                            if (j_cells[j+3][i].isCellFull() && !j_cells[j+3][i].isCellTakenByPlayer())
                            {
                                gameWin = true;
                                gameWinActivateComp();
                                break;
                            }
                        }
                    }

                }


                if (gameWin)
                {

                    break;
                }


            }

            if (gameWin)
            {
                break;
            }
        }
    }

    void gameWinActivate()
    {
        j_dropButtons[0].setEnabled(false);
        j_dropButtons[1].setEnabled(false);
        j_dropButtons[2].setEnabled(false);
        j_dropButtons[3].setEnabled(false);
        j_dropButtons[4].setEnabled(false);
        j_dropButtons[5].setEnabled(false);
        j_dropButtons[6].setEnabled(false);
        j_gameWinMessageText.setVisibility(View.VISIBLE);
        j_gameWinMessageText.setText("You win!");


        int tempWin = j_game_myPpl.get(position).getWins();
        j_game_myPpl.get(position).setWins(tempWin+1);
        String userNameParse = j_game_myPpl.get(position).getUsername();

        dbHelper.updateUserWins(j_game_myPpl.get(position).getWins(), j_game_myPpl.get(position).getLosses(), userNameParse);
    }

    void gameWinActivateComp()
    {
        j_dropButtons[0].setEnabled(false);  //https://stackoverflow.com/questions/23267915/does-setonclicklistener-force-button-to-be-clickable
        j_dropButtons[1].setEnabled(false);
        j_dropButtons[2].setEnabled(false);
        j_dropButtons[3].setEnabled(false);
        j_dropButtons[4].setEnabled(false);
        j_dropButtons[5].setEnabled(false);
        j_dropButtons[6].setEnabled(false);
        j_gameWinMessageText.setVisibility(View.VISIBLE);
        j_gameWinMessageText.setText("The computer wins!");


        int tempLosses = j_game_myPpl.get(position).getLosses();
        j_game_myPpl.get(position).setLosses(tempLosses+1);
        String userNameParse = j_game_myPpl.get(position).getUsername();

        dbHelper.updateUserWins(j_game_myPpl.get(position).getWins(), j_game_myPpl.get(position).getLosses(), userNameParse);
    }








    void checkBoardClick() {



        if (isPlayerTurn)
        {


            j_dropButtons[0].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    for (int i = 5; i > -1; i--) {
                        if (!j_cells[i][0].isCellFull())
                        {
                            setPlayerChipOnCell(i, 0);
                            break;
                        }
                        else if (j_cells[0][0].isCellFull())
                        {
                            Toast.makeText(GameActivity.this, "This row is occupied.", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }

                }
            });

            j_dropButtons[1].setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    for (int i = 5; i > -1; i--) {
                        if (!j_cells[i][1].isCellFull())
                        {
                            setPlayerChipOnCell(i, 1);
                            break;

                        } else if (j_cells[0][1].isCellFull())
                        {
                            Toast.makeText(GameActivity.this, "This row is occupied.", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }

                }
            });

            j_dropButtons[2].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    for (int i = 5; i > -1; i--) {
                        if (!j_cells[i][2].isCellFull()) {
                            setPlayerChipOnCell(i, 2);
                            break;
                        } else if (j_cells[0][2].isCellFull())
                        {
                            Toast.makeText(GameActivity.this, "This row is occupied.", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }

                }
            });

            j_dropButtons[3].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    for (int i = 5; i > -1; i--) {
                        if (!j_cells[i][3].isCellFull()) {
                            setPlayerChipOnCell(i, 3);
                            break;
                        } else if (j_cells[0][3].isCellFull())
                        {
                            Toast.makeText(GameActivity.this, "This row is occupied.", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }

                }
            });

            j_dropButtons[4].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    for (int i = 5; i > -1; i--) {
                        if (!j_cells[i][4].isCellFull()) {
                            setPlayerChipOnCell(i, 4);
                            break;
                        } else if (j_cells[0][4].isCellFull())
                        {
                            Toast.makeText(GameActivity.this, "This row is occupied.", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }

                }
            });

            j_dropButtons[5].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    for (int i = 5; i > -1; i--) {
                        if (!j_cells[i][5].isCellFull()) {
                            setPlayerChipOnCell(i, 5);
                            break;
                        } else if (j_cells[0][5].isCellFull())
                        {

                            Toast.makeText(GameActivity.this, "This row is occupied.", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }

                }
            });

            j_dropButtons[6].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    for (int i = 5; i > -1; i--) {
                        if (!j_cells[i][6].isCellFull())
                        {
                            setPlayerChipOnCell(i, 6);
                            break;
                        } else if (j_cells[0][6].isCellFull())
                        {

                            Toast.makeText(GameActivity.this, "This row is occupied.", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }

                }
            });

        }

    }

    }


