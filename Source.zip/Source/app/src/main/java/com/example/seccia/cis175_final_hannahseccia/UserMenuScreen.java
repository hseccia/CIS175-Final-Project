package com.example.seccia.cis175_final_hannahseccia;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;


public class UserMenuScreen extends Activity {

    TextView j_menu_welcomeText;

    Button j_menu_playBtn;
    Button j_menu_accountBtn;
    Button j_menu_logOutBtn;

    Intent j_account_screen;
    Intent j_main_screen;
    Intent j_load_screen;
    ArrayList<Persn> j_menu_myPpl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_menu_screen);

        j_menu_playBtn = (Button) findViewById(R.id.v_menu_playBtn);
        j_menu_accountBtn = (Button) findViewById(R.id.v_menu_accountBtn);
        j_menu_logOutBtn = (Button)findViewById(R.id.v_menu_logOutBtn);
        j_menu_welcomeText = (TextView)findViewById(R.id.v_menu_welcomeText);

        Intent previousIntent = getIntent();
        j_menu_myPpl = previousIntent.getParcelableArrayListExtra("Persons");
        int position = previousIntent.getIntExtra("Position",00);


        j_account_screen = new Intent(UserMenuScreen.this, Account.class);
        j_main_screen = new Intent(UserMenuScreen.this, MainActivity.class);
        j_load_screen = new Intent(UserMenuScreen.this, LoadScreen.class);

        String welcome = "Welcome back, " + j_menu_myPpl.get(position).getfName().toString() + "!";
        j_menu_welcomeText.setText(welcome);


        checkPlayButtonClick(position);
        checkAccountButtonClick(position);
        checkLogOutButtonClick();
    }

    void checkPlayButtonClick(final int position)
    {
        j_menu_playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                j_load_screen.putParcelableArrayListExtra("Persons", j_menu_myPpl);
                j_load_screen.putExtra("Position",position);
                startActivity(j_load_screen);

            }
        });
    }

    void checkAccountButtonClick(final int position)
    {

        j_menu_accountBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                j_account_screen.putParcelableArrayListExtra("Persons", j_menu_myPpl);
                j_account_screen.putExtra("Position",position);
                startActivity(j_account_screen);
            }
        });
    }

    void checkLogOutButtonClick()
    {
        j_menu_logOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                j_main_screen.putParcelableArrayListExtra("Persons", j_menu_myPpl);
                startActivity(j_main_screen);
            }
        });
    }
}
