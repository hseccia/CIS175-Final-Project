package com.example.seccia.cis175_final_hannahseccia;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class LoadScreen extends AppCompatActivity {

    TextView j_loadScreenText;
    ImageView j_loadScreenImg;
    ArrayList<Persn> j_load_myPpl;
    Intent j_game_screen;
    Animation rotate;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_screen);

        Intent previousIntent = getIntent();
        j_load_myPpl = previousIntent.getParcelableArrayListExtra("Persons");
        position = previousIntent.getIntExtra("Position", 00);
        j_game_screen = new Intent(LoadScreen.this, GameActivity.class);


        j_loadScreenText = (TextView) findViewById(R.id.v_loadScreenText);
        j_loadScreenImg = (ImageView) findViewById(R.id.v_loadScreenImg);


        rotate = AnimationUtils.loadAnimation(getBaseContext(), R.anim.rotate);

        new CountDownTimer(4000, 1000) {                                                  //https://stackoverflow.com/questions/10032003/how-to-make-a-countdown-timer-in-android

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {

                rotate();

            }
        }.start();




    }

    void rotate()
    {
        j_loadScreenImg.startAnimation(rotate);

        new CountDownTimer(4000, 1000) {                                                  //https://stackoverflow.com/questions/10032003/how-to-make-a-countdown-timer-in-android

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {

                j_game_screen.putParcelableArrayListExtra("Persons", j_load_myPpl);
                j_game_screen.putExtra("Position", position);
                startActivity(j_game_screen);

            }
        }.start();

    }

}
