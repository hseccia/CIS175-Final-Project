package com.example.seccia.cis175_final_hannahseccia;

public class Connect4Cell {

    private boolean cellFull;
    private boolean cellTakenByPlayer;


    public boolean isCellFull() {
        return cellFull;
    }

    public void setCellFull(boolean cellFull) {
        this.cellFull = cellFull;
    }

    public boolean isCellTakenByPlayer() {
        return cellTakenByPlayer;
    }

    public void setCellTakenByPlayer(boolean cellTakenByPlayer) {
        this.cellTakenByPlayer = cellTakenByPlayer;
    }


}
