package com.example.seccia.cis175_final_hannahseccia;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Account extends AppCompatActivity {

    TextView j_account_winLossesNumText;
    TextView j_account_winLossesText;
    TextView j_account_firstNameText;
    TextView j_account_lastNameText;
    TextView j_account_usernameText;
    TextView j_account_username;
    TextView j_account_emailText;
    TextView j_account_passwordText;
    TextView j_account_ageText;
    TextView j_account_age;

    Button j_account_updateBtn;
    Button j_account_deleteBtn;
    Button j_account_backButton;

    EditText j_account_email;
    EditText j_account_password;
    EditText j_account_firstName;
    EditText j_account_lastName;


    Intent j_menu_screen;
    Intent j_main_screen;

    ArrayList<Persn> j_info_myPpl;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_screen);

        j_account_winLossesNumText = (TextView) findViewById(R.id.v_account_winLossesNumText);
        j_account_winLossesText = (TextView) findViewById(R.id.v_account_winLossesText);
        j_account_firstNameText = (TextView) findViewById(R.id.v_account_firstNameText);
        j_account_lastNameText = (TextView) findViewById(R.id.v_account_lastNameText);
        j_account_usernameText = (TextView) findViewById(R.id.v_account_usernameText);
        j_account_username = (TextView) findViewById(R.id.v_account_username);
        j_account_emailText = (TextView) findViewById(R.id.v_account_e_mailText);
        j_account_passwordText = (TextView) findViewById(R.id.v_account_passwordText);
        j_account_ageText  = (TextView) findViewById(R.id.v_account_ageText);
        j_account_age = (TextView) findViewById(R.id.v_account_age);

        j_account_updateBtn = (Button) findViewById(R.id.v_account_updateBtn);
        j_account_deleteBtn = (Button) findViewById(R.id.v_account_deleteBtn);
        j_account_backButton = (Button) findViewById(R.id.v_account_backButton);

        j_account_email = (EditText) findViewById(R.id.v_account_e_mail);
        j_account_password = (EditText) findViewById(R.id.v_account_password);
        j_account_firstName = (EditText) findViewById(R.id.v_account_firstName);
        j_account_lastName = (EditText) findViewById(R.id.v_account_lastName);

        j_menu_screen = new Intent(Account.this, UserMenuScreen.class);
        j_main_screen = new Intent(Account.this,MainActivity.class);

        Intent previousIntent = getIntent();
        j_info_myPpl = previousIntent.getParcelableArrayListExtra("Persons");
        int position = previousIntent.getIntExtra("Position", 0);

        dbHelper = new DatabaseHelper(this);

        winLossesPercentCalculate(position);
        setTextFields(position);
        checkUpdateButtonClick(position);
        checkDeleteButtonClick(position);
        checkBackButtonClick(position);

    }

    void winLossesPercentCalculate(int position)
    {


        if (j_info_myPpl.get(position).getWins() == 0)
        {
            j_account_winLossesNumText.setText("0%");
        }
        else if (j_info_myPpl.get(position).getLosses() == 0)
        {
            j_account_winLossesNumText.setText("100%");
        }
        else
        {
            int winLossPercent = (j_info_myPpl.get(position).getWins() / j_info_myPpl.get(position).getLosses()) * 100;        //turning it into a percentage
            j_account_winLossesNumText.setText(Integer.toString(winLossPercent) + "%");
        }
    }

    void setTextFields(int position)
    {
        j_account_firstName.setText(j_info_myPpl.get(position).getfName());
        j_account_lastName.setText(j_info_myPpl.get(position).getlName());
        j_account_username.setText(j_info_myPpl.get(position).getUsername());
        j_account_password.setText(j_info_myPpl.get(position).getPassword());
        j_account_email.setText(j_info_myPpl.get(position).getEmail());
        j_account_age.setText(Integer.toString(j_info_myPpl.get(position).getAge()));
    }

    void checkDeleteButtonClick(final int position)
    {
        j_account_deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dbHelper.deleteUser(j_info_myPpl.get(position).getUsername());
                j_info_myPpl.remove(position);
                Toast.makeText(Account.this, "Account deleted.", Toast.LENGTH_SHORT).show();
                j_main_screen.putParcelableArrayListExtra("Persons", j_info_myPpl);
                startActivity(j_main_screen);


            }
        });
    }


    void checkBackButtonClick(final int position)
    {
        j_account_backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                j_menu_screen.putParcelableArrayListExtra("Persons", j_info_myPpl);
                j_menu_screen.putExtra("Position",position);
                startActivity(j_menu_screen);
            }
        });

    }

    void checkUpdateButtonClick(final int position)
    {

        j_account_updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String updateFName;
                String updateLName;
                String updatepassword;
                String updateEmail;
                String usernameParse;

                updateFName = j_account_firstName.getText().toString();
                updateLName = j_account_lastName.getText().toString();
                updatepassword = j_account_password.getText().toString();
                updateEmail = j_account_email.getText().toString();
                usernameParse = j_info_myPpl.get(position).getUsername().toString();

                j_info_myPpl.get(position).setfName(updateFName);
                j_info_myPpl.get(position).setlName(updateLName);
                j_info_myPpl.get(position).setPassword(updatepassword);
                j_info_myPpl.get(position).setEmail(updateEmail);

                dbHelper.updateUser(updateFName, updateLName, updatepassword, updateEmail, usernameParse);

                Toast.makeText(Account.this, "Account information updated.", Toast.LENGTH_SHORT).show();

                j_menu_screen.putParcelableArrayListExtra("Persons", j_info_myPpl);
                j_menu_screen.putExtra("Position",position);
                startActivity(j_menu_screen);

            }
        });


    }


}
