package com.example.seccia.cis175_final_hannahseccia;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AddUser extends Activity {

    TextView j_add_header;
    TextView j_add_fNameDisplay;
    TextView j_add_lNameDisplay;
    TextView j_add_usernameDisplay;
    TextView j_add_passwordDisplay;
    TextView j_add_emailDisplay;
    TextView j_add_ageDisplay;
    EditText j_add_fName;
    EditText j_add_lName;
    EditText j_add_username;
    EditText j_add_password;
    EditText j_add_email;
    EditText j_add_age;
    Button j_add_addButton;
    Button j_add_backButton;

    ArrayList<Persn> j_add_myPpl;
    Intent j_main_screen;
    DatabaseHelper dbHelper;
    Boolean uniqueUsername = true;                                                                          //makes sure the user doesn't try override existing username
    Boolean allFields;                                                                                      //makes sure the user fills out all text fields



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user_screen);

          j_add_header = (TextView)findViewById(R.id.v_add_header);
          j_add_fNameDisplay= (TextView)findViewById(R.id.v_add_fNameDisplay);
          j_add_lNameDisplay= (TextView)findViewById(R.id.v_add_lNameDisplay);
          j_add_usernameDisplay = (TextView)findViewById(R.id.v_add_usernameDisplay);
          j_add_passwordDisplay = (TextView)findViewById(R.id.v_add_passwordDisplay);
          j_add_emailDisplay = (TextView)findViewById(R.id.v_add_email);
          j_add_ageDisplay = (TextView)findViewById(R.id.v_add_age);
          j_add_fName = (EditText)findViewById(R.id.v_add_fName);
          j_add_lName = (EditText)findViewById(R.id.v_add_lName);
          j_add_username = (EditText)findViewById(R.id.v_add_userame);
          j_add_password  = (EditText)findViewById(R.id.v_add_password);
          j_add_email = (EditText)findViewById(R.id.v_add_email);
          j_add_age  = (EditText)findViewById(R.id.v_add_age);
          j_add_addButton = (Button)findViewById(R.id.v_add_addButton);
          j_add_backButton = (Button)findViewById(R.id.v_add_backButton);

          j_main_screen = new Intent(AddUser.this, MainActivity.class);
          Intent previousIntent = getIntent();
          j_add_myPpl = previousIntent.getParcelableArrayListExtra("Persons");

          dbHelper = new DatabaseHelper(this);

          addButtonPressed();
          backButtonPressed();

    }

    void addPerson()
    {


        Persn person = new Persn();

        person.setfName(j_add_fName.getText().toString());                                  //same code as preset names but
        person.setlName(j_add_lName.getText().toString());                                  //dynamic
        person.setUsername(j_add_username.getText().toString());
        person.setPassword(j_add_password.getText().toString());
        person.setEmail(j_add_email.getText().toString());
        person.setAge(Integer.parseInt(j_add_age.getText().toString()));

        j_add_myPpl.add(person);


        dbHelper.addNewUser((j_add_fName.getText().toString()), (j_add_lName.getText().toString()),
                (j_add_username.getText().toString()), (j_add_password.getText().toString()),
                (j_add_email.getText().toString()), Integer.parseInt(j_add_age.getText().toString()));




    }

    void addButtonPressed()
    {
        j_add_addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                int tableRowSize = dbHelper.db_numOfRows();
                for (int i = 0; i < tableRowSize; i++)
                {
                    if (j_add_username.getText().toString().equals(j_add_myPpl.get(i).getUsername()))       //if username entered already in the arraylist/db
                    {
                        Toast.makeText(AddUser.this, "This username is already in use.", Toast.LENGTH_SHORT).show();
                        uniqueUsername = false;
                    }
                    if (!j_add_username.getText().toString().equals(j_add_myPpl.get(i).getUsername()))
                    {
                        uniqueUsername = true;
                    }
                }

                if (j_add_fName.getText().toString().equals("") || j_add_lName.getText().toString().equals("") || j_add_username.getText().toString().equals("") || j_add_password.getText().toString().equals("") || j_add_email.getText().toString().equals("") || j_add_age.getText().toString().equals(""))
                    //^^^ if any of the text fields are empty
                {
                    Toast.makeText(AddUser.this, "Please fill in all fields before proceeding.", Toast.LENGTH_SHORT).show();
                    allFields = false;
                }
                else
                {
                    allFields = true;
                }

                if (uniqueUsername && allFields)
                {
                    addPerson();
                    j_add_fName.setText("");
                    j_add_lName.setText("");
                    j_add_username.setText("");
                    j_add_password.setText("");
                    j_add_email.setText("");
                    j_add_age.setText("");
                    Toast.makeText(AddUser.this, "User registered.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    void backButtonPressed()
    {
        j_add_backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                j_main_screen.putParcelableArrayListExtra("Persons", j_add_myPpl);
                startActivity(j_main_screen);

            }
        });
    }



}
